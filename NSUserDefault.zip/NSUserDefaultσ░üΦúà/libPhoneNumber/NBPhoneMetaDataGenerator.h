//
//  NBPhoneMetaDataGenerator.h
//  libPhoneNumber
//
//

#import <Foundation/Foundation.h>


@interface NBPhoneMetaDataGenerator : NSObject

- (void)generateMetadataClasses;

@end
