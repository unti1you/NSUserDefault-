#import <Foundation/Foundation.h>
#import "NBPhoneMetaData.h"

@interface NBPhoneMetadataTestAD : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestBR : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestAU : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestBB : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestAE : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestCX : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestBS : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestDE : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestKR : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestNZ : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestPL : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestYT : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestCA : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestAO : NBPhoneMetaData
@end

@interface NBPhoneMetadataTest800 : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestFR : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestGG : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestHU : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestSG : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestJP : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestCC : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestMX : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestUS : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestIT : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestAR : NBPhoneMetaData
@end

@interface NBPhoneMetadataTest979 : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestGB : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestBY : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestCN : NBPhoneMetaData
@end

@interface NBPhoneMetadataTestRE : NBPhoneMetaData
@end

