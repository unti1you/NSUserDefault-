#import <Foundation/Foundation.h>

@interface NBMetadataCoreMapper : NSObject

+ (NSArray *)ISOCodeFromCallingNumber:(NSString *)key;

@end

