#import <Foundation/Foundation.h>

@interface NBMetadataCoreTestMapper : NSObject

+ (NSArray *)ISOCodeFromCallingNumber:(NSString *)key;

@end

