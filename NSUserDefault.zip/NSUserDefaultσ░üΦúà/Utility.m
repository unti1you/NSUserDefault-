//
//  Utility.m
//  EpadSign
//
//  Created by linzh on 14-12-19.
//  Copyright (c) 2014年 linzh. All rights reserved.
//
#import "Utility.h"
#import "sys/utsname.h"
#import "NBPhoneNumberUtil.h"

@interface Utility ()


@end



@implementation Utility


static Utility *_utilityinstance=nil;
static dispatch_once_t utility;

+(id)Share
{
    dispatch_once(&utility, ^ {
        _utilityinstance = [[Utility alloc] init];
    });
	return _utilityinstance;
}
+(int)uid{
    return [[[Utility Share] userid] intValue];
}
- (NSString*)userid
{
    if (!_userid) {
    }
    return _userid;
}


#pragma mark -
/**
 *	保存obj的array到本地，如果已经存在会替换本地。
 *
 *	@param	obj	待保存的obj
 *	@param	key	保存的key
 */
+ (void)saveToArrayDefaults:(id)obj forKey:(NSString*)key
{
    [self saveToArrayDefaults:obj replace:obj forKey:key];
}
+ (void)saveToArrayDefaults:(id)obj replace:(id)oldobj forKey:(NSString*)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSArray *array = [defaults valueForKey:key];
    
    NSMutableArray *marray = [NSMutableArray array];
    if (!oldobj) {
        oldobj = obj;
    }
    if (array) {
        [marray addObjectsFromArray:array];
        if ([marray containsObject:oldobj]) {
            [marray replaceObjectAtIndex:[marray indexOfObject:oldobj] withObject:obj];
        }else{
            [marray addObject:obj];
        }
    }else{
        [marray addObject:obj];
    }
    [defaults setValue:marray forKey:key];
    [defaults synchronize];
}

+ (BOOL)removeForArrayObj:(id)obj forKey:(NSString*)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSArray *array = [defaults valueForKey:key];
    
    NSMutableArray *marray = [NSMutableArray array];
    if (array) {
        [marray addObjectsFromArray:array];
        if ([marray containsObject:obj]) {
            [marray removeObject:obj];
        }
    }
    if (marray.count) {
        [defaults setValue:marray forKey:key];
    }else{
        [defaults removeObjectForKey:key];
    }
    [defaults synchronize];
    return marray.count;
}
/**
 *	保存obj到本地
 *
 *	@param	obj	数据
 *	@param	key	键
 */
+ (void)saveToDefaults:(id)obj forKey:(NSString*)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:obj forKey:key];
    [defaults synchronize];
}

+ (id)defaultsForKey:(NSString*)key
{
    return [[NSUserDefaults standardUserDefaults] valueForKey:key];
}
+ (void)removeForKey:(NSString*)key
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(BOOL)isValidPhoneNumber:(NSString *)phoneNumber withCountryCode:(NSNumber *)countryCode
{
    NBPhoneNumberUtil *phoneUtil = [[NBPhoneNumberUtil alloc] init];
    NSString* region = [phoneUtil getRegionCodeForCountryCode:countryCode];
    
    return [Utility isValidPhoneNumber:phoneNumber withRegion:region];
}
+(BOOL)isValidPhoneNumber:(NSString *)phoneNumber withRegion:(NSString*)region
{
    NBPhoneNumberUtil *phoneUtil = [[NBPhoneNumberUtil alloc] init];
    NSError *anError = nil;
    NBPhoneNumber *myNumber = [phoneUtil parse:phoneNumber
                                 defaultRegion:region
                                         error:&anError];
    NBEPhoneNumberType type = [phoneUtil getNumberType:myNumber];
    
    if ([region isEqualToString:@"CN"]) {
        return  [phoneUtil isValidNumber:myNumber] && (type == NBEPhoneNumberTypeMOBILE);
    }
    
    return [phoneUtil isValidNumber:myNumber];
}

#pragma mark -- 国外手机号 重新构造用户id
+(NSString*)getUserIdWithMobile:(NSString*)mobile
{
    NSMutableString *_mobile = [NSMutableString stringWithString:mobile];
    [_mobile replaceOccurrencesOfString:@"[^0-9]"
                            withString:@""
                               options:NSRegularExpressionSearch
                                 range:NSMakeRange(0, _mobile.length)];

    return [NSString stringWithFormat:@"00%@",_mobile];
}
#pragma mark -- 验证号码注意号码更新了种类删除正则表达式
+(BOOL)verifyPhoneNumber:(NSString *)phoneNumber
{
    
    if (!phoneNumber) {
        return NO;
    }
    /**
     * 手机号码
     * 移动: 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188,145,147
     * 联通: 130,131,132,152,155,156,185,186
     * 电信: 133,1349,153,180,189,181
     */
    NSString *MOBILE = @"^1(3[0-9]|5[0-35-9]|8[025-9])\\d{8}$";
    
    /**
     * 中国移动:China Mobile
     * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,183,187,188,145,147
     */
    NSString *CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[2378]4[57])\\d)\\d{7}$";
    
    /**
     * 中国联通:China Unicom
     * 130,131,132,152,155,156,185,186
     */
    NSString *CU = @"^1(3[0-2]|5[256]|8[56])\\d{8}$";
    
    /**
     * 中国电信:China Telecom
     * 133,1349,153,180,189
     * 177(4g)
     */
    NSString *CT = @"^1((33|53|77|8[019])[0-9]|349)\\d{7}$";
    
    
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",MOBILE];
    NSPredicate *regextestcm =[NSPredicate predicateWithFormat:@"SELF MATCHES %@",CM];
    NSPredicate *regextestcu =[NSPredicate predicateWithFormat:@"SELF MATCHES %@",CU];
    NSPredicate *regextestct =[NSPredicate predicateWithFormat:@"SELF MATCHES %@",CT];
    
    if (([regextestmobile evaluateWithObject:phoneNumber] == YES)
        ||([regextestcm evaluateWithObject:phoneNumber] == YES)
        ||([regextestcu evaluateWithObject:phoneNumber] == YES)
        ||([regextestct evaluateWithObject:phoneNumber] == YES))
    {
        return YES;
    }
    return NO;
}

#pragma mark TimeTravel
- (NSString*)timeToNow:(NSString*)theDate
{
    if (!theDate) {
        return nil;
    }
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *d=[dateFormatter dateFromString:theDate];
    if (!d) {
        return theDate;
    }
    
    NSTimeInterval late=[d timeIntervalSince1970]*1;
    
    
    NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval now=[dat timeIntervalSince1970]*1;
    NSString *timeString=@"";
    
    NSTimeInterval cha=(now-late)>0 ? (now-late) : 0;
    
    if (cha/3600<1) {
        timeString = [NSString stringWithFormat:@"%f", cha/60];
        timeString = [timeString substringToIndex:timeString.length-7];
        timeString=[NSString stringWithFormat:@"%@ 分前", timeString];
        
    }else if (cha/3600>1 && cha/3600<24) {
        timeString = [NSString stringWithFormat:@"%f", cha/3600];
        timeString = [timeString substringToIndex:timeString.length-7];
        timeString=[NSString stringWithFormat:@"%@ 小时前", timeString];
    }
    else
    {
        timeString = [NSString stringWithFormat:@"%.0f 天前",cha/3600/24];
    }
    
    return timeString;
}

+ (NSString*)timeAfterNow:(NSString*)theDate
{
    if (!theDate) {
        return nil;
    }else
    {
        NSString *str = [NSString stringWithFormat:@"%@",theDate];
        if ([str isEqualToString:@"0"])
        {
            return @"";
        }else
        {
            
            NSString *timeString=@"";
            if ([theDate isEqualToString:@"长期"]) {
                return theDate;
            }else
            {
                NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                NSDate *d=[dateFormatter dateFromString:theDate];
                
                NSTimeInterval late=[d timeIntervalSince1970]*1;
                NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
                NSTimeInterval now=[dat timeIntervalSince1970]*1;
                
                NSTimeInterval cha= late - now;
                //NSLog(@"cha = %f",cha);
                if(cha<0){
                    return @"已截止";
                }
                if (cha/3600<1) {
                    timeString = [NSString stringWithFormat:@"%f", cha/60];
                    timeString = [timeString substringToIndex:timeString.length-7];
                    timeString=[NSString stringWithFormat:@"%@ 分", timeString];
                    
                }else if (cha/3600>1 && cha/3600<24) {
                    timeString = [NSString stringWithFormat:@"%f", cha/3600];
                    timeString = [timeString substringToIndex:timeString.length-7];
                    timeString=[NSString stringWithFormat:@"%@ 小时 %d 分", timeString,(int)cha%3600];
                }
                else
                {
                    timeString = [NSString stringWithFormat:@"%.0f 天 %d 小时",cha/3600/24,(int)(cha/3600)%24];
                }
                return timeString;
            }
            
        }
    }
}

#pragma mark -- 设备类型
+(NSDeviceTypeOfiPhone)deviceType
{
    // 需要#import "sys/utsname.h"
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    if ([deviceString isEqualToString:@"iPhone1,1"])
        return NSDeviceTypeOfiPhone1G;//iPhone 1G
    if ([deviceString isEqualToString:@"iPhone1,2"])
        return NSDeviceTypeOfiPhone3G;//iPhone 3G
    if ([deviceString isEqualToString:@"iPhone2,1"])
        return NSDeviceTypeOfiPhone3GS;//iPhone 3GS
    if ([deviceString isEqualToString:@"iPhone3,2"])
        return NSDeviceTypeOfiPhoneVerzion4;//Verizon iPhone 4
    if ([deviceString isEqualToString:@"iPhone3,1"])
        return NSDeviceTypeOfiPhone4;//4
    if ([deviceString isEqualToString:@"iPhone4,1"])
        return NSDeviceTypeOfiPhone4s;//4s
    if ([deviceString isEqualToString:@"iPhone5,2"])
        return NSDeviceTypeOfiPhone5;//5
    if ([deviceString isEqualToString:@"iPhone7,2"])
        return NSDeviceTypeOfiPhone6;//6
    if ([deviceString isEqualToString:@"iPhone7,1"])
        return NSDeviceTypeOfiPhone6p;//6p
    
    //    if ([deviceString isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
    //    if ([deviceString isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
    //    if ([deviceString isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
    //    if ([deviceString isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
    //    if ([deviceString isEqualToString:@"iPad1,1"])      return @"iPad";
    //    if ([deviceString isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    //    if ([deviceString isEqualToString:@"iPad2,2"])      return @"iPad 2 (GSM)";
    //    if ([deviceString isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    //    if ([deviceString isEqualToString:@"i386"])         return @"Simulator";
    //    if ([deviceString isEqualToString:@"x86_64"])       return @"Simulator";
    NSLog(@"NOTE: Unknown device type: %@", deviceString);
    return NSDeviceTypeOfiPhoneNone;
}


+(NSString*)configString:(NSString *)string
{
    NSMutableString *text = [NSMutableString stringWithString:@""];
    for (NSUInteger index = 0 ; index < string.length; ++index) {
        
        NSString *subString = [string substringWithRange:NSMakeRange(index, 1)];
        
        [text appendFormat:@"%@%@",@"*",subString];
    }
    [text appendFormat:@"%@",@"*"];
    
    return text;
}
@end
