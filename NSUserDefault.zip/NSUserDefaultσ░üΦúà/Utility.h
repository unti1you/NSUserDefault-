//
//  Utility.h
//  EpadSign
//
//  Created by linzh on 14-12-19.
//  Copyright (c) 2014年 linzh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger, NSDeviceTypeOfiPhone)
{
    NSDeviceTypeOfiPhoneNone = 0,
    NSDeviceTypeOfiPhone1G,
    NSDeviceTypeOfiPhone3G,
    NSDeviceTypeOfiPhone3GS,
    NSDeviceTypeOfiPhoneVerzion4,
    NSDeviceTypeOfiPhone4,
    NSDeviceTypeOfiPhone4s,
    NSDeviceTypeOfiPhone5,
    NSDeviceTypeOfiPhone6,
    NSDeviceTypeOfiPhone6p
};

@interface Utility : NSObject

@property (nonatomic,strong) NSString  *userid;
@property (nonatomic,strong) NSString  *username;


+(id)Share;
+(int)uid;
- (NSString*)timeToNow:(NSString*)theDate;
+(NSString*)timeAfterNow:(NSString*)theDate;
+ (BOOL)removeForArrayObj:(id)obj forKey:(NSString*)key;
+ (void)saveToDefaults:(id)obj forKey:(NSString*)key;
+ (void)saveToArrayDefaults:(id)obj forKey:(NSString*)key;
+ (void)saveToArrayDefaults:(id)obj replace:(id)oldobj forKey:(NSString*)key;
+ (id)defaultsForKey:(NSString*)key;
+ (void)removeForKey:(NSString*)key;

#pragma mark -- 国外手机号 重新构造用户id
+(NSString*)getUserIdWithMobile:(NSString*)mobile;

+(BOOL)isValidPhoneNumber:(NSString *)phoneNumber withCountryCode:(NSNumber *)countryCode;
+(BOOL)isValidPhoneNumber:(NSString *)phoneNumber withRegion:(NSString*)region;
+(BOOL)verifyPhoneNumber:(NSString *)phoneNumber;

+(NSDeviceTypeOfiPhone)deviceType;

//字符串中插入＊ 字符 ，比如 “ada” 转换为 "*a*d*a*"
+(NSString*)configString:(NSString*)string;

@end
